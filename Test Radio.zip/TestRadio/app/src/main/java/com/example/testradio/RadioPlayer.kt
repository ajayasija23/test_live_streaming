package com.example.testradio

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.testradio.databinding.ActivityRadioPlayerBinding
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.source.hls.HlsMediaSource
import com.google.android.exoplayer2.upstream.DataSource

import com.google.android.exoplayer2.upstream.DefaultHttpDataSource




class RadioPlayer:AppCompatActivity() {
    private lateinit var binding:ActivityRadioPlayerBinding
    private lateinit var exoPlayer: ExoPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityRadioPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        exoPlayer=ExoPlayer.Builder(this).build()
        binding.radioPlayer.player=exoPlayer
        binding.radioPlayer.setShowMultiWindowTimeBar(false)
        createMedia()

    }

    private fun createMedia() {
        val url=intent.getStringExtra("url")
        val seekTime=intent.getLongExtra("seekTime",0)
        val isHls=intent.getBooleanExtra("isHls",false)
        if (isHls.not()){
            exoPlayer.setMediaItem(MediaItem.fromUri(url.toString()))
        }else{
            val dataSourceFactory: DataSource.Factory = DefaultHttpDataSource.Factory()
            val hlsMediaSource: HlsMediaSource = HlsMediaSource.Factory(dataSourceFactory)
                .createMediaSource(MediaItem.fromUri(url.toString()))
            exoPlayer.setMediaSource(hlsMediaSource)
        }
        exoPlayer.seekTo(seekTime)
        exoPlayer.prepare()
        exoPlayer.playWhenReady=true
    }

}